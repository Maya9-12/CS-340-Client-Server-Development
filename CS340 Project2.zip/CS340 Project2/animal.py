from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

    
class AnimalShelter (object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        
        # Initializing the MongoClient 
        self.client = MongoClient('mongodb://%s:%s@localhost:47059/test?authSource=AAC' % ("aacuser", "aacuser"))
        self.database = self.client['AAC']
        
# Complete this create method to implement the C in CRUD    
    def create(self, data):
        
        #Insert data into collection
        if data is not None:
            insert = self.database.animals.insert_one(data)  # data should be dictionary
            if insert!=0:
                return True
            else:
                return False    
        else:
            raise Exception("Nothing to save, because data parameter is empty") 
            
# Complete this create method to implement the R in CRUD
    def read(self, data=None):
        if data is not None:
            results = self.database.animals.find(data)
            return results
        else:
            print("Nothing to read, because data parameter is empty")
            return

#Read All
    def readAll(self, data):
        results = self.database.animals.find(data)
        
        return results
                    
# Create method to implement the U in CRUD.
    def update(self, initial = None, change = None):
        if initial:
            results = self.database.animals.find_one(initial, {"_id":False, "name":1, "type":1})
            
            #Update entry with new data
            if results is not None:
                newData = self.database.animals.update_one(initial, change)
                print("Successfully Updated To: ")
                return change
            
            #Create new entry
            else: 
                newData = self.database.animals.insert_one(change)
                print("Successfully Added: ")
                return newData
        else:
            results = self.database.animals.find_one({}, {"_id":False, "name":1, "type":1})
            print("Nothing to update, because data parameter is empty")
            return False

# Create method to implement the D in CRUD.
    def delete(self, remove = None):
        
        #Delete data
        if remove:
            results = self.database.animals.find_one(remove, {"_id":False, "name":1, "type":1})
            
            #if data is found, delete
            if results is not None:
                remove = self.database.animals.delete_one(remove)
                print("File Removed")
                return 
            #if data is not found
            else:
                print("File not Found")
                return
        else:
            print("Nothing to delete, because data parameter is empty")
            return False